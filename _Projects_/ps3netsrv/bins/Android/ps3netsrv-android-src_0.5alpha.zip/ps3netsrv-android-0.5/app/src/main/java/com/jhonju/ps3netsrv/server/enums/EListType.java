package com.jhonju.ps3netsrv.server.enums;

public enum EListType {
    LIST_TYPE_NONE,
    LIST_TYPE_ALLOWED,
    LIST_TYPE_BLOCKED
}
