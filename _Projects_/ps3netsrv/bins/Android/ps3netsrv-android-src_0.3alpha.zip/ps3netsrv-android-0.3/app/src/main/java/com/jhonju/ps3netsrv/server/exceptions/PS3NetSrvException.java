package com.jhonju.ps3netsrv.server.exceptions;

public class PS3NetSrvException extends Exception {
    public PS3NetSrvException(String message) {
        super(message);
    }
}
