package com.jhonju.ps3netsrv.server.results;

public class ReadDirResult {
    public final long dirSize;

    public ReadDirResult(long dirSize) {
        this.dirSize = dirSize;
    }
}
