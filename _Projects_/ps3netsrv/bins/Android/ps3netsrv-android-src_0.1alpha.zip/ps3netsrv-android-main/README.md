# ps3netsrv-android
Android ps3netsrv

Work in progress.

There is 2 main issues I need to fix yet:
1. Put the server running as a service (to avoid Android put the application to "sleep").
2. Some devices are experiencing a low server performance (I'm trying to discover what is happening yet).

Features missing from original ps3netsrv that I still wants to develop:
1. Multi part ISO.
2. Virtual ISO from "JB Games".
3. Encrypted ISO.
4. Whitelist / Blacklist of client IP's.
5. Limit the maximum number of clients.

I also have to improve the interface, because it's a lot uggly.

The project is developed using only native Android/Java libraries, to avoid problems with licensing.

If you want to contribute, feel free to open a PR.
