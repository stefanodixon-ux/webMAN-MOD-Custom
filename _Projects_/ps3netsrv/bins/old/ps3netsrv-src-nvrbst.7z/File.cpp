#include "File.h"

#include <stdio.h>

#include "common.h"
#include "compat.h"


File::File() : enc_type_(kDiscTypeNone), region_count_(0), region_info_(NULL) {
	fd = INVALID_FD;
}

File::~File() {
    region_count_ = 0;
    enc_type_ = kDiscTypeNone;
    if (region_info_ != NULL) {
        delete[] region_info_;
        region_info_ = NULL;
    }
	if (FD_OK(fd))
		this->close();
}

int File::open(const char *path, int flags) {
	if (FD_OK(fd))
		this->close();
	
	fd = open_file(path, flags);
	if (!FD_OK(fd))
		return -1;

    // Check for redump encrypted mode by looking for the ".key" file with the ".iso".
    size_t path_len = strlen(path);
    if (path_len >= 4 && path[path_len - 4] == '.' && path[path_len - 3] == 'i' && path[path_len - 2] == 's' && path[path_len - 1] == 'o') {
        char *key_path = strdup(path);
        if (key_path != NULL) {
            key_path[path_len - 3] = 'k';
            key_path[path_len - 2] = 'e';
            key_path[path_len - 1] = 'y';
        }

        // Check if key_path exsists, and create the aes_dec_ context if so.
        file_t key_fd = open_file(key_path, flags);
        if (FD_OK(fd)) {
            char keystr[32];
            if (read_file(key_fd, keystr, sizeof(keystr)) == sizeof(keystr)) {
                unsigned char key[16];
                keystr_to_keyarr(keystr, key);
                if (aes_setkey_dec(&aes_dec_, key, 128) != 0)
                    printf("ERROR: open > key > aes_setkey_dec.\n");
                enc_type_ = kDiscTypeRedump;
            }
            close_file(key_fd);
        }
        free(key_path);
    }

    // Store the ps3 information sectors.
    file_stat_t st;
    unsigned char sec0sec1[kSectorSize * 2] = {0};
    if (fstat(&st) >= 0 && st.file_size >= kSectorSize * 2) {
        // Restore the origional position eventhough we just opened, it should be at 0... (can be safe here, no performance worries for open).
        int64_t initial_read_position = seek(0, SEEK_CUR);
        if (initial_read_position != 0)
            if (seek(0, SEEK_SET) < 0LL)
                printf("ERROR: open > seek1.\n");

        // Note: It's important to bypass our "read(...)" overload because encryption flag could already be set, and, then it'll try to read the region_info_.
        if (read_file(fd, sec0sec1, sizeof(sec0sec1)) == sizeof(sec0sec1)) {
            // Populate the region information.
            if (region_info_ != NULL)
                delete[] region_info_;

            region_count_ = char_arr_BE_to_uint(sec0sec1) * 2 - 1;
            region_info_ = new PS3RegionInfo[region_count_];
            for (size_t i = 0; i < region_count_; ++i) {
                // Store the region information in address format.
                region_info_[i].encrypted = (i % 2 == 1);
                region_info_[i].regions_first_addr = (i == 0 ? 0LL : region_info_[i - 1].regions_last_addr + 1LL);
                region_info_[i].regions_last_addr = static_cast<int64_t>(char_arr_BE_to_uint(sec0sec1 + 12 + (i * 4)) - (i % 2 == 1 ? 1LL : 0LL)) * kSectorSize + kSectorSize - 1LL;                
            }
        }

        // Restore to the initial read position (probably 0).
        if (seek(initial_read_position, SEEK_SET) < 0LL)
            printf("ERROR: open > seek2.\n");
    }

    // If encryption is still set to none (sec0sec1 will be zeroed out if it didn't succeed).
    if (enc_type_ == kDiscTypeNone) {
        // The 3k3y watermarks located at 0xF70: (D|E)ncrypted 3K BLD.
        static const unsigned char k3k3yEnWatermark[16] = {0x45, 0x6E, 0x63, 0x72, 0x79, 0x70, 0x74, 0x65, 0x64, 0x20, 0x33, 0x4B, 0x20, 0x42, 0x4C, 0x44};
        static const unsigned char k3k3yDecWatermark[16] = {0x44, 0x6E, 0x63, 0x72, 0x79, 0x70, 0x74, 0x65, 0x64, 0x20, 0x33, 0x4B, 0x20, 0x42, 0x4C, 0x44};
        
        if (memcmp(&k3k3yEnWatermark[0], &sec0sec1[0xF70], sizeof(k3k3yEnWatermark)) == 0) {
            // Grab the D1 from the 3k3y sector.
            unsigned char key[16];
            memcpy(key, &sec0sec1[0xF80], 0x10);
  
            // Convert D1 to KEY and generate the aes_dec_ context.
            unsigned char key_d1[] = {0x38, 11, 0xcf, 11, 0x53, 0x45, 0x5b, 60, 120, 0x17, 0xab, 0x4f, 0xa3, 0xba, 0x90, 0xed};
            unsigned char iv_d1[] = {0x69, 0x47, 0x47, 0x72, 0xaf, 0x6f, 0xda, 0xb3, 0x42, 0x74, 0x3a, 0xef, 170, 0x18, 0x62, 0x87};
            aes_context aes_d1;
            if (aes_setkey_enc(&aes_d1, key_d1, 128) != 0)
                printf("ERROR: open > 3k3y > aes_setkey_enc.\n");
            if (aes_crypt_cbc(&aes_d1, AES_ENCRYPT, 16, &iv_d1[0], key, key) != 0)
                printf("ERROR: open > 3k3y > aes_crypt_cbc.\n");
            if (aes_setkey_dec(&aes_dec_, key, 128) != 0)
                printf("ERROR: open > 3k3y > aes_setkey_dec.\n");
            enc_type_ = kDiscType3k3yEnc;
        } else if (memcmp(&k3k3yDecWatermark[0], &sec0sec1[0xF70], sizeof(k3k3yDecWatermark)) == 0) {
            enc_type_ = kDiscType3k3yDec;
        }
    }
	return 0;
}

int File::close(void) {
    // Little extra encryption logic cleanup.
    region_count_ = 0;
    enc_type_ = kDiscTypeNone;
    if (region_info_ != NULL) {
        delete[] region_info_;
        region_info_ = NULL;
    }

	return close_file(fd);
}

ssize_t File::read(void *buf, size_t nbyte) {
    // In non-encrypted mode just do what is normally done.
    if (enc_type_ == kDiscTypeNone || region_info_ == NULL)
	    return read_file(fd, buf, nbyte);

    int64_t read_position = seek(0, SEEK_CUR);
    ssize_t ret = read_file(fd, buf, nbyte);
    if (read_position < 0LL) {
        printf("ERROR: read > enc > seek: Returing decrypted data.\n");
        return ret;
    }

    // If this is a 3k3y iso, and the 0xF70 data is being requests by ps3, we should null it out.
    if (enc_type_ == kDiscType3k3yDec || enc_type_ == kDiscType3k3yEnc) {
        if (read_position + ret >= 0xF70LL && read_position <= 0x1070LL) {
            // Zero out the 0xF70 - 0x1070 overlap.
            unsigned char *bufb = reinterpret_cast<unsigned char *>(buf);
            unsigned char *buf_overlap_start = read_position < 0xF70LL ? bufb + 0xF70LL - read_position : bufb;
            memset(buf_overlap_start, 0x00, read_position + ret < 0x1070LL ? ret - (buf_overlap_start - bufb) : 0x100 - (buf_overlap_start - bufb));
        }

        // If it's a dec image then return, else go on to the decryption logic.
        if (enc_type_ == kDiscType3k3yDec)
            return ret;
    }

    // Encrypted mode, check if the request lies in an encrypted range.
    for (size_t i = 0; i < region_count_; ++i) {
        if (read_position >= region_info_[i].regions_first_addr && read_position <= region_info_[i].regions_last_addr) {
            // We found the region, decrypt if needed.
            if (!region_info_[i].encrypted)
                return ret;

            // Decrypted the region before sending it back.
            decrypt_data(aes_dec_, reinterpret_cast<unsigned char *>(buf), ret / kSectorSize, read_position / kSectorSize);

            // TODO(Temporary): Sanity check, we are assuming that reads always start at a begining of a sector. And that all reads will be multiples of kSectorSize.
            //                  Note: Both are easy fixes, but, code can be more simple + efficent if these two conditions are true (which they look to be from initial testing).
            if (nbyte % kSectorSize != 0 || ret % kSectorSize != 0 || read_position % kSectorSize != 0)
                printf("ERROR: encryption assumptions were not met, code needs to be updated, your game is probably about to crash: nbyte 0x%x, ret 0x%x, read_position 0x%I64x.\n", nbyte, ret, read_position);
            return ret;
        }
    }

    printf("ERROR: LBA request wasn't in the region_info_ for an encrypted iso? RP: 0x%I64x, RC: 0x%x, LR (0x%I64x-0x%I64x).\n", read_position, region_count_, region_count_ > 0 ? region_info_[region_count_ - 1].regions_first_addr : 0LL, region_count_ > 0 ? region_info_[region_count_ - 1].regions_last_addr : 0LL);
    return ret;
}

ssize_t File::write(void *buf, size_t nbyte) {
	return write_file(fd, buf, nbyte);
}

int64_t File::seek(int64_t offset, int whence) {
	return seek_file(fd, offset, whence);
}

int File::fstat(file_stat_t *fs) {
	return fstat_file(fd, fs);
}


// Convert a hex string into a byte array.
//   Note: const char *str: must be zero terminated, and have a length of exactly 32 characters.
unsigned char File::asciischar_to_byte(char input) {
    if(input >= '0' && input <= '9')
        return input - '0';
    if(input >= 'A' && input <= 'F')
        return input - 'A' + 10;
    if(input >= 'a' && input <= 'f')
        return input - 'a' + 10;

    printf("ERROR: asciischar_to_byte.\n");
    return 0x00;
}
void File::keystr_to_keyarr(const char (&str)[32], unsigned char (&arr)[16]) {
    for (size_t i = 0; i < sizeof(arr); ++i)
        arr[i] = asciischar_to_byte(str[i*2]) * 16 + asciischar_to_byte(str[i*2+1]);
}

// Convert 4 bytes in big-endian format, to an unsigned integer.
unsigned int File::char_arr_BE_to_uint(unsigned char *arr) {
    return arr[3] + 256*(arr[2] + 256*(arr[1] + 256*arr[0]));
}

// Reset the iv to a particular lba.
void File::reset_iv(unsigned char (&iv)[16], unsigned int lba) {
    memset(iv, 0, 12);

    iv[12] = (lba & 0xFF000000)>>24;
    iv[13] = (lba & 0x00FF0000)>>16;
    iv[14] = (lba & 0x0000FF00)>> 8;
    iv[15] = (lba & 0x000000FF)>> 0;
}

// Main function that will decrypt the sector(s) (needs to be a multiple of 2048).
void File::decrypt_data(aes_context &aes, unsigned char *data, int sector_count, unsigned int start_lba) {
    for (int i=0; i < sector_count; ++i) {
        reset_iv(iv_, start_lba + i);
        if (aes_crypt_cbc(&aes, AES_DECRYPT, kSectorSize, &iv_[0], &data[kSectorSize*i], &data[kSectorSize*i]) != 0) {
            printf("ERROR: decrypt_data > aes_crypt_cbc.\n");
            return;
        }
    }
}
