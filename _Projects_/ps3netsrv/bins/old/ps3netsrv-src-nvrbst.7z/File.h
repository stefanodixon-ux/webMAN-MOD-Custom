#ifndef __FILE_H__
#define __FILE_H__

#include <polarssl/aes.h>

#include "AbstractFile.h"


// Struct to store region information (storing addrs instead of lba since we need to compare the addr anyway, so would have to multiple or divide every read if storing lba).
struct PS3RegionInfo {
    bool encrypted;
    int64_t regions_first_addr;
    int64_t regions_last_addr;
};

// Enum to decide the Files encryption type.
enum PS3EncDiscType {
    kDiscTypeNone,
    kDiscType3k3yDec,
    kDiscType3k3yEnc,
    kDiscTypeRedump
};


class File : public AbstractFile {
protected:
	file_t fd;

public:
	File();
	virtual ~File();
	
	virtual int open(const char *path, int flags);
	virtual int close(void);
	virtual ssize_t read(void *buf, size_t nbyte);
	virtual ssize_t write(void *buf, size_t nbyte);
	virtual int64_t seek(int64_t offset, int whence);
	virtual int fstat(file_stat_t *fs);

private:
    static const size_t kSectorSize = 2048;

    // Decryption related functions.
    unsigned char asciischar_to_byte(char input);
    void keystr_to_keyarr(const char (&str)[32], unsigned char (&arr)[16]);
    unsigned int char_arr_BE_to_uint(unsigned char *arr);
    void reset_iv(unsigned char (&iv)[16], unsigned int lba);
    void decrypt_data(aes_context &aes, unsigned char *data, int sector_count, unsigned int start_lba);

    // Decryption related variables.
    PS3EncDiscType enc_type_;
    aes_context aes_dec_;
    size_t region_count_;
    PS3RegionInfo *region_info_;

    // Micro optimization, only ever used by decrypt_data(...).
    unsigned char iv_[16];
};

#endif
