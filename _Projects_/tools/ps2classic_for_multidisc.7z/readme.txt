Multi-disc functionality with ps2_netemu has finally been reversed!
Custom multi-disc packages are now possible.
For now, additional discs and configs need to be manually encrypted with this custom ps2classic executable.
All credits go to kozarovv for reversing, and this write up.

I have tested and confirmed it is working with a custom Grandia III package, with disc two and original CONFIG2 NET config re-encrypted using this tool.

From kozarovv:

For now only disc change with reset has been tested, and there is high probability that swap without reset is broken in emulator itself.
For plain users I suggest to wait until changes will be ( if they will be :) ) implemented into GUI apps like PS2 classics GUI or pop-fe2.

Requirements:
- Modified ps2classic cli app.
- Per disc CONFIG files.
- Game discs with added LIMG segment.
- DISC.IDX file (used to preserve current disc number).

App arguments example:
Code:
ps2classic.exe e [cex/dex] [klicensee] [iso] [out data] [real out name] [CID] [disc number]
ps2classic.exe e cex klic.bin game.iso ISO.BIN.ENC2 ISO.BIN.ENC2 2P0001-PS2U10000_00-0000111122223333 2

CONFIG examples based on Grandia 3:

Config file example for disc1 (CONFIG):
Code:
3D 00 00 00 A8 3E 00 00 00 00 00 00 53 4C 55 53
2D 32 31 33 33 34 00 02 00

Config file example for disc2 (CONFIG2):
Code:
3D 00 00 00 A8 3E 00 00 00 00 00 00 53 4C 55 53
2D 32 31 33 33 45 00 02 01

Additionally to make emulator to remember current disc, put zeroed 2 bytes DISC.IDX file in to /game/<game id>/USRDIR/.

Config files also need to be encrypted using modified ps2classic app!

Like you can see config file should have game ID after 00 00 00 00 terminator, and after ID, there are multidisc info bytes. ID should match one from the disc.
Last bytes 00 0X 0Y, where X is overall disc count, and Y is disc number - 1. This data is later copied to DISC.IDX. Up to 9 discs is supported in single PKG.

Final file structure should look like this:

Code:
[<GAME ID>]
  [USRDIR]
  [SAVEDATA]
  SCEVMC0.VME
  SCEVMC1.VME
  CONFIG
  CONFIG2
  ISO.BIN.ENC
  ISO.BIN.ENC2
  ISO.BIN.EDAT
  PS3LOGO.DAT
  PARAM.SFO
  ICON0.PNG
  PIC0.PNG
  PIC1.PNG
  
WARNING! Modified version of ps2classic is working only on Windows, but this is isn't actually any limitation,
I just made some additional Windows specific changes to make it compile under VS, which likely break Linux compilation.
Changes regarding multidiscs are only in ps2classic.c file, and search for disc_num to understand them or to port them to different forks.

	//prepare disc number
	disc_num = (disc_num - 1) << 24;
	wbe32(meta_buffer+(i*PS2_META_ENTRY_SIZE)+0x14, disc_num | segment_number);
