#ifndef __LIBCRASHDUMP_SYSTEM_H__
#define __LIBCRASHDUMP_SYSTEM_H__


// libcrashdump_system_21EEF746  // ?
// libcrashdump_system_88CCAA2A  // ?


#endif // __LIBCRASHDUMP_SYSTEM_H__ 
