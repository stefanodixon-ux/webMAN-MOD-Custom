#ifndef __XSETTING_H__
#define __XSETTING_H__



//extern int xsetting_0AF1F161(void);




#endif // __XSETTING_H__ 
