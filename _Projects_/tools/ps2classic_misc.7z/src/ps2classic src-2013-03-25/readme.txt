ps2classic by +ps3dev-net
encrypts/decrypts ps2 classics for ps3

Home: http://gitorious.ps3dev.net/ps2classic

License Type: GNU General Public License version 3 (GPLv3)

