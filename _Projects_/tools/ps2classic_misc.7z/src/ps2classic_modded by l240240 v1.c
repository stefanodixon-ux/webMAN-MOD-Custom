/*
 *  ps2classic.c (c) 2013 flatz, user
 *  	GPL v3
 */

#include "tools.h"
#include "types.h"

#include <stdio.h>
#include <string.h>

/*
 *  IMPORTANT FOR FWRITE FILES > 2GB ON 32BIT SYSTEMS
 *  add		-D"_LARGEFILE64_SOURCE"
 *  and		-D"_FILE_OFFSET_BITS=64"
 *  to		CFLAGS
 */

#define PS2_META_SEGMENT_START		1
#define PS2_DATA_SEGMENT_START		2
#define PS2_DEFAULT_SEGMENT_SIZE	0x4000
#define PS2_META_ENTRY_SIZE		0x20

#define PS2_VMC_ENCRYPT			1
#define PS2_VMC_DECRYPT			0

/*
 * keys
 */
uint8_t ps2_per_console_seed[0x10] = {
	0xD9, 0x2D, 0x65, 0xDB, 0x05, 0x7D, 0x49, 0xE1,
	0xA6, 0x6F, 0x22, 0x74, 0xB8, 0xBA, 0xC5, 0x08
};

uint8_t ps2_key_cex_meta[0x10] = {
	0x38, 0x9D, 0xCB, 0xA5, 0x20, 0x3C, 0x81, 0x59,
	0xEC, 0xF9, 0x4C, 0x93, 0x93, 0x16, 0x4C, 0xC9
};

uint8_t ps2_key_cex_data[0x10] = {
	0x10, 0x17, 0x82, 0x34, 0x63, 0xF4, 0x68, 0xC1,
	0xAA, 0x41, 0xD7, 0x00, 0xB1, 0x40, 0xF2, 0x57
};

uint8_t ps2_key_cex_vmc[0x10] = {
	0x64, 0xE3, 0x0D, 0x19, 0xA1, 0x69, 0x41, 0xD6,
	0x77, 0xE3, 0x2E, 0xEB, 0xE0, 0x7F, 0x45, 0xD2
};

uint8_t ps2_key_dex_meta[0x10] = {
	0x2B, 0x05, 0xF7, 0xC7, 0xAF, 0xD1, 0xB1, 0x69,
	0xD6, 0x25, 0x86, 0x50, 0x3A, 0xEA, 0x97, 0x98
};

uint8_t ps2_key_dex_data[0x10] = {
	0x74, 0xFF, 0x7E, 0x5D, 0x1D, 0x7B, 0x96, 0x94,
	0x3B, 0xEF, 0xDC, 0xFA, 0x81, 0xFC, 0x20, 0x07
};

uint8_t ps2_key_dex_vmc[0x10] = {
	0x30, 0x47, 0x9D, 0x4B, 0x80, 0xE8, 0x9E, 0x2B,
	0x59, 0xE5, 0xC9, 0x14, 0x5E, 0x10, 0x64, 0xA9
};

uint8_t ps2_iv[0x10] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

uint8_t fallback_header_hash[0x10] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01
};

uint8_t npd_omac_key2[0x10] = {
	0x6B, 0xA5, 0x29, 0x76, 0xEF, 0xDA, 0x16, 0xEF,
	0x3C, 0x33, 0x9F, 0xB2, 0x97, 0x1E, 0x25, 0x6B
};

uint8_t npd_omac_key3[0x10] = {
	0x9B, 0x51, 0x5F, 0xEA, 0xCF, 0x75, 0x06, 0x49,
	0x81, 0xAA, 0x60, 0x4D, 0x91, 0xA5, 0x4E, 0x97
};

uint8_t npd_kek[0x10] = {
	0x72, 0xF9, 0x90, 0x78, 0x8F, 0x9C, 0xFF, 0x74,
	0x57, 0x25, 0xF0, 0x8E, 0x4C, 0x12, 0x83, 0x87
};

/*
 * global
 */
uint8_t *klicensee;
static int ps3_cex_img = 1;

static void ps2_set_iv(uint8_t *iv) {
	memcpy(iv, ps2_iv, 0x10);
}

/*
 *  ps2_iso9660_sig
 */
void ps2_iso9660_sig(FILE *f, const char *img_in) {
	/* iso9660 offset */
	if(fseek(f, 0x8000, SEEK_SET) == 0) {
		uint8_t buf[8];

		if(fread(buf, 1, 6, f)) {
			if(buf[0] != 0x01 && buf[1] != 0x43 && buf[2] != 0x44 && buf[3] != 0x30 && buf[4] != 0x30 && buf[5] != 0x31) {
				/* skip */
				if(ps3_cex_img == 1)
					printf("[* CEX] PS2 Classic:\n");
				else
					printf("[* DEX] PS2 Classic:\n");
					printf(" input\t\t%s [ERROR]\n", img_in);

				fclose(f);
				exit(0);
			}
		}

		fseek(f, 0, SEEK_SET);
	}
}

/*
 *  ps2_content_id
 */
void ps2_content_id(FILE *f, char *s1) {
	int i, j = 0;
	uint8_t buf[16];

	/* title_id */
	while(fread(buf, 1, 4, f)) {
		/* PAL-E */
		if(buf[0] == 'S' && buf[1] == 'C' && buf[2] == 'E' && buf[3] == 'S') {
			i = 0x45;
			j = ftell(f) - 4;
			break;
		}

		if(buf[0] == 'S' && buf[1] == 'L' && buf[2] == 'E' && buf[3] == 'S') {
			i = 0x45;
			j = ftell(f) - 4;
			break;
		}

		/* NTSC-US & NTSC-U/C */
		if(buf[0] == 'S' && buf[1] == 'C' && buf[2] == 'U' && buf[3] == 'S') {
			i = 0x55;
			j = ftell(f) - 4;
			break;
		}

		if(buf[0] == 'S' && buf[1] == 'L' && buf[2] == 'U' && buf[3] == 'S') {
			i = 0x55;
			j = ftell(f) - 4;
			break;
		}

		/* NTSC-J */
		if(buf[0] == 'S' && buf[1] == 'C' && buf[2] == 'P' && buf[3] == 'S') {
			i = 0x4a;
			j = ftell(f) - 4;
			break;
		}

		if(buf[0] == 'S' && buf[1] == 'L' && buf[2] == 'P' && buf[3] == 'A') {
			i = 0x4a;
			j = ftell(f) - 4;
			break;
		}

		if(buf[0] == 'S' && buf[1] == 'L' && buf[2] == 'P' && buf[3] == 'M') {
			i = 0x4a;
			j = ftell(f) - 4;
			break;
		}

		if(buf[0] == 'S' && buf[1] == 'L' && buf[2] == 'P' && buf[3] == 'S') {
			i = 0x4a;
			j = ftell(f) - 4;
			break;
		}
	}

	if(fseek(f, j, SEEK_SET) == 0) {
		if(fread(buf, 1, 11, f))
			snprintf(s1, 37, "EP0000-NP%cD%c%c%c%c%c_00-0000000000000000", i, buf[5], buf[6], buf[7], buf[9], buf[10]);
	}
}

/*
 * ps2_build_limg
 */
void ps2_build_limg(const char *img_in, int64_t size) {
	int i, b_size = 0;
	uint8_t buf[8], tmp[8];

	FILE *f = fopen(img_in, "rb+");

	/* limg offset */
	if(fseek(f, -0x4000, SEEK_END) == 0) {
		if(fread(buf, 1, 4, f)) {
			/* skip */
			if(buf[0] == 0x4c && buf[1] == 0x49 && buf[2] == 0x4d && buf[3] == 0x47) {
				printf("[*] LIMG Header:\n\t\t[OK]\n");
				fclose(f);
				return;
			}
		}
	}

	for(i = 0; i < 8; i++)
		buf[i] = tmp[i] = 0x00;

	/* seek end */
	fseek(f, 0, SEEK_END);

	if(size > 0x2BC00000)
		b_size = 0x800; /* dvd */
	else
		b_size = 0x930; /* cd */

	if(b_size == 0x800) {
		buf[3] = 0x01;
		tmp[2] = 0x08;
	} else {
		buf[3] = 0x02;
		tmp[2] = 0x09;
		tmp[3] = 0x30;
	}

	/* print output */
	printf("[*] LIMG Header:\n 4C 49 4D 47 ");

	fwrite("LIMG", 1, 4, f);
	fwrite(buf, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", buf[i]);

	/* sector */
	snprintf(buf, 7, "%02lx", (size - 0x4000) / b_size);

	#define hex(c) (c <= '9' ? c - '0' : c <= 'F' ? c - 'A' + 10 : c - 'a' + 10)

	buf[1] = hex(buf[0]) << 4 | hex(buf[1]);
	buf[2] = hex(buf[2]) << 4 | hex(buf[3]);
	buf[3] = hex(buf[4]) << 4 | hex(buf[5]);
	buf[0] = 0x00;

	fwrite(buf, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", buf[i]);

	fwrite(tmp, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", tmp[i]);
		printf("\n");

	/* 0x4000 - 16 */
	for(i = 0; i < 0x3FF0; i++)
		fwrite(&buf[0], 1, 1, f);
		fclose(f);
}

/*
 *  ps2_build_header
 */
static void ps2_build_header(uint8_t *buf, int npd_type, const char *content_id, const char *img_out, int64_t img_size) {
	char *tmp;
	int i, len;
	uint8_t npd_omac_key[0x10];
	//u8 test_hash[16] = {0xBF, 0x2E, 0x44, 0x15, 0x52, 0x8F, 0xD7, 0xDD, 0xDB, 0x0A, 0xC2, 0xBF, 0x8C, 0x15, 0x87, 0x51};

	wbe32(buf, 0x50533200);			/* PS2\0 */
	wbe16(buf + 0x04, 0x01);		/* ver major */
	wbe16(buf + 0x06, 0x01);		/* ver minor */
	wbe32(buf + 0x08, npd_type);		/* NPD type XX */
	wbe32(buf + 0x0c, 0x01);		/* type */

	wbe64(buf + 0x88, img_size); 			/* iso size */
	wbe32(buf + 0x84, PS2_DEFAULT_SEGMENT_SIZE);	/* segment size */

	strncpy(buf + 0x10, content_id, 0x30);

	for(i = 0; i < 0x10; i++)
		npd_omac_key[i] = npd_kek[i] ^ npd_omac_key2[i];

	get_rand(buf + 0x40, 0x10); /* npdhash1 */
	//memcpy(buffer + 0x40, test_hash, 0x10);

  	len = strlen(img_out) + 0x30;
	tmp = (char *)malloc(len + 1);

	memcpy(tmp, buf + 0x10, 0x30);
	strcpy(tmp + 0x30, img_out);

	aesOmacMode1(buf + 0x50, tmp, len, npd_omac_key3, 128); /* npdhash2 */
	aesOmacMode1(buf + 0x60, buf, 0x60, npd_omac_key, 128); /* npdhash3 */

	/* free */
	free(tmp);
}

/*
 * ps2_decrypt_image
 */
void ps2_decrypt_image(const char *img_in, const char *img_out, const char *meta_out) {
	FILE *in, *me, *out;
	int i, read, seg_size, child_seg_num;
	int64_t img_size;
	uint8_t *data_buf, *meta_buf, iv[0x10], ps2_data_key[0x10], ps2_meta_key[0x10], header[0x100];

	int64_t c, flush_size, decr_size, total_size;
	int percent;

	decr_size = c = percent = 0;

	read = 0;

	/* open files */
	in = fopen(img_in, "rb");
	me = fopen(meta_out, "wb");
	out = fopen(img_out, "wb");

	/* file info */
	read = fread(header, 0x100, 1, in);
	seg_size = be32(header + 0x84);
	img_size = be64(header + 0x88);
	child_seg_num = seg_size / PS2_META_ENTRY_SIZE;

	total_size = img_size;
	flush_size = total_size / 100;

	if(ps3_cex_img == 1)
		printf("[* CEX] PS2 Classic:\n");
	else
		printf("[* DEX] PS2 Classic:\n");

	printf(" input\t\t%s\n seg_size\t0x%08x\n img_size\t0x%08lx\n output\t\t%s\n", img_in, seg_size, img_size, img_out);

	/* allocate buffers */
	data_buf = (uint8_t *)malloc(seg_size * child_seg_num);
	meta_buf = (uint8_t *)malloc(seg_size);

	/* generate keys */
	if(ps3_cex_img == 1) {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	} else {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	/* decrypt iso */
	fseek(in, seg_size, SEEK_SET);
	
	while(read = fread(meta_buf, 1, seg_size, in)) {
		/* decrypt meta */
		aes128cbc(ps2_meta_key, iv, meta_buf, read, meta_buf);
		fwrite(meta_buf, read, 1, me);

		read = fread(data_buf, 1, seg_size * child_seg_num, in);
		for(i = 0; i < child_seg_num; i++)	
			aes128cbc(ps2_data_key, iv, data_buf + (i * seg_size), seg_size, data_buf + (i * seg_size));

		if(img_size >= read)
			fwrite(data_buf, read, 1, out);
		else
			fwrite(data_buf, img_size, 1, out);
		
		c += read;
		if(c >= flush_size) {
			percent += 1;
			decr_size = decr_size + c;
			printf("Decrypted: %03lx%  %08lx\n/%08lx\n", percent, encr_size, total_size);
			c = 0;
		}

		img_size -= read;
	}

	/* free */
	free(data_buf);
	free(meta_buf);

	fclose(in);
	fclose(me);
	fclose(out);
}

/*
 * ps2_encrypt_image
 */
void ps2_encrypt_image(const char *img_in, const char *img_out) {
	FILE *in, *out;
	int64_t img_size;
	uint8_t *data_buf, *meta_buf, *ps2_header, iv[0x10], content_id[0x40], ps2_data_key[0x10], ps2_meta_key[0x10];
	uint32_t i, read, seg_num, child_seg_num;

	int64_t c, flush_size, decr_size, total_size;
	int percent;

	decr_size = c = percent = 0;

	read = seg_num = 0;
	child_seg_num = 0x200;

	/* open files */
	in = fopen(img_in, "rb");
	out = fopen(img_out, "wb");

	/* iso9660 check */
	ps2_iso9660_sig(in, img_in);

	/* content id */
	ps2_content_id(in, content_id);

	/* file info */
	fseek(in, 0, SEEK_END);
	img_size = ftell(in);
	fseek(in, 0, SEEK_SET);

	total_size = img_size;
	flush_size = total_size / 100;

	/* limg section */
	ps2_build_limg(img_in, img_size);

	if(ps3_cex_img == 1)
		printf("[* CEX] PS2 Classic:\n");
	else
		printf("[* DEX] PS2 Classic:\n");

	printf(" input\t\t%s\n seg_size\t0x%08x\n img_size\t0x%08lx\n content_id\t%s\n output\t\t%s\n", img_in, PS2_DEFAULT_SEGMENT_SIZE, img_size, content_id, img_out);

	/* prepare buffers */
	data_buf = (uint8_t *)malloc(PS2_DEFAULT_SEGMENT_SIZE * 0x200);
	meta_buf = (uint8_t *)malloc(PS2_DEFAULT_SEGMENT_SIZE);
	ps2_header = (uint8_t *)malloc(PS2_DEFAULT_SEGMENT_SIZE);
	memset(ps2_header, 0, PS2_DEFAULT_SEGMENT_SIZE);

	/* generate keys */
	if(ps3_cex_img == 1) {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	} else {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	/* write incomplete ps2 header */
	ps2_build_header(ps2_header, 2, content_id, img_out, img_size);
	fwrite(ps2_header, PS2_DEFAULT_SEGMENT_SIZE, 1, out);

	/* write encrypted image */
	while(read = fread(data_buf, 1, PS2_DEFAULT_SEGMENT_SIZE * child_seg_num, in)) {
		/* last segments? */
		if(read != (PS2_DEFAULT_SEGMENT_SIZE * child_seg_num)) {
			child_seg_num = (read / PS2_DEFAULT_SEGMENT_SIZE);
			if((read % PS2_DEFAULT_SEGMENT_SIZE) > 0)
				child_seg_num++;
		}

		/* encrypt data and create meta */	
		for(i = 0; i < child_seg_num; i++) {	
			aes128cbc_enc(ps2_data_key, iv, data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE), PS2_DEFAULT_SEGMENT_SIZE, data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE));
			sha1(data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE), PS2_DEFAULT_SEGMENT_SIZE, meta_buf + (i * PS2_META_ENTRY_SIZE));
			wbe32(meta_buf + (i * PS2_META_ENTRY_SIZE) + 0x14, seg_num);
			seg_num++;
		}

		/* encrypt meta */
		aes128cbc_enc(ps2_meta_key, iv, meta_buf, PS2_DEFAULT_SEGMENT_SIZE, meta_buf);
		
		/* write meta and data */
		fwrite(meta_buf, PS2_DEFAULT_SEGMENT_SIZE, 1, out);
		fwrite(data_buf, PS2_DEFAULT_SEGMENT_SIZE * child_seg_num, 1, out);

		c += read;
		if(c >= flush_size) {
			percent += 1;
			encr_size = encr_size + c;
			printf("Encrypted: %03lx%  %08lx\n/%08lx\n", percent, encr_size, total_size);

			c = 0;
		}

		memset(data_buf, 0, PS2_DEFAULT_SEGMENT_SIZE * child_seg_num);
	}

	//finalize ps2_header
	// - wtf is between signature and first segment?

	/* free */
	free(data_buf);
	free(meta_buf);
	free(ps2_header);

	fclose(in);
	fclose(out);
}

/*
 * ps2_crypt_vmc
 */
void ps2_crypt_vmc(const char *vmc_in, const char *vmc_out, uint8_t *eid_root_key, const int crypt_mode) {
	FILE *in, *out;
	uint8_t *data_buf, iv[0x10], ps2_vmc_key[0x10];
	uint32_t read = 0;

	/* open files */
	in = fopen(vmc_in, "rb");
	out = fopen(vmc_out, "wb");

	/* allocate buffer */
	data_buf = (uint8_t *)malloc(PS2_DEFAULT_SEGMENT_SIZE);

	/* generate keys */
	if(ps3_cex_img == 1) {
		aes256cbc_enc(eid_root_key, eid_root_key + 0x20, ps2_per_console_seed, 0x10, iv);
		memcpy(ps2_vmc_key, ps2_key_cex_vmc, 0x10);
	} else {
		aes256cbc_enc(eid_root_key, eid_root_key + 0x20, ps2_per_console_seed, 0x10, iv);
		memcpy(ps2_vmc_key, ps2_key_dex_vmc, 0x10);
	}

	memset(iv + 8, 0, 8);

	while(read = fread(data_buf, 1, PS2_DEFAULT_SEGMENT_SIZE, in)) {
		/* decrypt or encrypt vmc */
		if(crypt_mode == PS2_VMC_DECRYPT)
			aes128cbc(ps2_vmc_key, ps2_iv, data_buf, read, data_buf);
		else
			aes128cbc_enc(ps2_vmc_key, ps2_iv, data_buf, read, data_buf);

		fwrite(data_buf, read, 1, out);
	}

	/* free */
	free(data_buf);

	fclose(in);
	fclose(out);
}

/*
 * usage
 */
void usage(const char *s1) {
	printf("usage:\n\t%s e|d c|d [klic] [in] [out]\n\t%s ve|vd c|d [in] [out] [eid_root_key]\n"
		"<!---->\n"
		"\te|d\tenc|dec\n"
		"\tc|d\tcex|dex\n"
		"\tve|vd\tvmc|vme\n", s1, s1);

	exit(0);
}

/*
 * main
 */
int main(int argc, char **argv) {
	if(argc == 1)
		usage(argv[0]);

	if(strncmp(argv[2], "d", 1) == 0)
		ps3_cex_img = 0;

	klicensee = mmap_file(argv[3]);

	if(strncmp(argv[1], "d", 1) == 0) {
		if(argc == 7)
			ps2_decrypt_image(argv[4], argv[5], argv[6]);
		else
			usage(argv[0]);

	} else if(strncmp(argv[1], "e", 1) == 0) {
		if(argc == 6)
			ps2_encrypt_image(argv[4], argv[5]);
		else
			usage(argv[0]);

	} else if(strncmp(argv[1], "vd", 2) == 0 || strncmp(argv[1], "ve", 2) == 0) {
		uint8_t *eid_root_key;

		eid_root_key = 0;

		if(argc == 6) {
			eid_root_key = mmap_file(argv[5]);

		} else if(argc == 5) {
			eid_root_key = (char *)malloc(0x30);
			memset(eid_root_key, 0, 0x30);

		} else
			usage(argv[0]);

		if(strncmp(argv[1], "vd", 2) == 0)
			ps2_crypt_vmc(argv[3], argv[4], eid_root_key, PS2_VMC_DECRYPT);
		else
			ps2_crypt_vmc(argv[3], argv[4], eid_root_key, PS2_VMC_ENCRYPT);

		/* free */
		free(eid_root_key);
	}
}

[+] added limg section
[+] added iso9660 check
[+] auto content_id generator, wont ask user for any input