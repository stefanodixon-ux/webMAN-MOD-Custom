/*+-----------------------------+*/
/*|2013 USER                    |*/
/*|decrypt algos by flatz       |*/
/*|                             |*/
/*|GPL v3,  DO NOT USE IF YOU   |*/
/*|DISAGREE TO RELEASE SRC :P   |*/
/*+-----------------------------+*/

#include "tools.h"
#include "types.h"

#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>

// !!!---- IMPORTANT FOR FWRITE FILES > 2GB ON 32BIT SYSTEMS ----!!!
//  add 	-D"_LARGEFILE64_SOURCE"
//  and		-D"_FILE_OFFSET_BITS=64"
//  to		CFLAGS
// !!!-----------------------------------------------------------!!!

#define PS2_META_SEGMENT_START		1
#define PS2_DATA_SEGMENT_START		2
#define PS2_DEFAULT_SEGMENT_SIZE	0x4000
#define PS2_META_ENTRY_SIZE		0x20

#define PS2_VMC_ENCRYPT			1
#define PS2_VMC_DECRYPT			0

//prototypes
void ps2_encrypt_image(char mode[], char image_name[], char data_file[], char real_out_name[], char CID[]);
void ps2_decrypt_image(char mode[], char image_name[], char meta_file[], char data_file[]);
void ps2_crypt_vmc(char mode[], char vmc_path[], char vmc_out[], int crypt_mode);
static void build_ps2_header(u8 * buffer, int npd_type, char content_id[], char filename[], s64 iso_size);
void vmc_hash(const char *mc_in);
void ps2_iso9660_sig(FILE *f, const char *img_in);
void ps2_build_limg(const char *img_in, int64_t size);

//keys
u8 ps2_per_console_seed[] = { 0xD9, 0x2D, 0x65, 0xDB, 0x05, 0x7D, 0x49, 0xE1, 0xA6, 0x6F, 0x22, 0x74, 0xB8, 0xBA, 0xC5, 0x08 };

u8 ps2_key_cex_meta[] = { 0x38, 0x9D, 0xCB, 0xA5, 0x20, 0x3C, 0x81, 0x59, 0xEC, 0xF9, 0x4C, 0x93, 0x93, 0x16, 0x4C, 0xC9 };
u8 ps2_key_cex_data[] = { 0x10, 0x17, 0x82, 0x34, 0x63, 0xF4, 0x68, 0xC1, 0xAA, 0x41, 0xD7, 0x00, 0xB1, 0x40, 0xF2, 0x57 };
u8 ps2_key_cex_vmc[] = { 0x64, 0xE3, 0x0D, 0x19, 0xA1, 0x69, 0x41, 0xD6, 0x77, 0xE3, 0x2E, 0xEB, 0xE0, 0x7F, 0x45, 0xD2 };

u8 ps2_key_dex_meta[] = { 0x2B, 0x05, 0xF7, 0xC7, 0xAF, 0xD1, 0xB1, 0x69, 0xD6, 0x25, 0x86, 0x50, 0x3A, 0xEA, 0x97, 0x98 };
u8 ps2_key_dex_data[] = { 0x74, 0xFF, 0x7E, 0x5D, 0x1D, 0x7B, 0x96, 0x94, 0x3B, 0xEF, 0xDC, 0xFA, 0x81, 0xFC, 0x20, 0x07 };
u8 ps2_key_dex_vmc[] = { 0x30, 0x47, 0x9D, 0x4B, 0x80, 0xE8, 0x9E, 0x2B, 0x59, 0xE5, 0xC9, 0x14, 0x5E, 0x10, 0x64, 0xA9 };

u8 ps2_iv[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

u8 fallback_header_hash[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 };

u8 npd_omac_key2[] = {0x6B,0xA5,0x29,0x76,0xEF,0xDA,0x16,0xEF,0x3C,0x33,0x9F,0xB2,0x97,0x1E,0x25,0x6B};
u8 npd_omac_key3[] = {0x9B,0x51,0x5F,0xEA,0xCF,0x75,0x06,0x49,0x81,0xAA,0x60,0x4D,0x91,0xA5,0x4E,0x97};
u8 npd_kek[] = {0x72,0xF9,0x90,0x78,0x8F,0x9C,0xFF,0x74,0x57,0x25,0xF0,0x8E,0x4C,0x12,0x83,0x87};

u8 * klicensee;

static void set_ps2_iv(u8 iv[])
{
	memcpy(iv, ps2_iv, 0x10);
}

/*
 *  vmc proper hash
 */
void vmc_hash(const char *mc_in) {
    
    int i, segment_count = 0, TotalSize=0 ;
    uint8_t segment_hashes[16384], segment_data[16384], sha1_hash[0x14];
    u32 read = 0;
    
	int64_t c, mc_size;
	int percent;
	
	mc_size = c = percent = 0;
    
    memset(segment_hashes, 0, sizeof(segment_hashes));
    
    FILE *f = fopen(mc_in, "rb+");
    
    if(fseek(f, 0, SEEK_SET) == 0) {
        uint8_t buf[8];
        
        if(fread(buf, 1, 8, f)) {
            if(buf[0] != 0x53 && buf[1] != 0x6F && buf[2] != 0x6E && buf[3] != 0x79 && buf[4] != 0x20 && buf[5] != 0x50 && buf[6] != 0x53 && buf[7] != 0x32 && buf[8] != 0x20)
            {
                printf("Not a valid Virtual Memory Card...:\n");
                
                fclose(f);
                exit(0);
            }
        }
        
        fseeko(f, 0, SEEK_END);
        TotalSize = ftello(f);
        
        segment_count = (TotalSize - sizeof(segment_data)) / sizeof(segment_data);
        
        for (i = 0; i < segment_count; i++)
        {
            fseek(f, (i * sizeof(segment_data)), SEEK_SET);
            read = fread(segment_data, 1, sizeof(segment_data), f);
            //fwrite(segment_data, 1, sizeof(segment_data), out);
            sha1(segment_data, sizeof(segment_data), sha1_hash);
            memcpy(segment_hashes + i * sizeof(sha1_hash), sha1_hash, sizeof(sha1_hash));
            
            c += read;
            percent += 1;
            mc_size = mc_size + c;
            printf("Rehash: Block %03d | Offset 0x%08lx\n", percent, mc_size);
            fflush(stdout);
            c = 0;
            
        }
        
        fseek(f, (segment_count * sizeof(segment_data)), SEEK_SET);
        
        fwrite(segment_hashes, 1, sizeof(segment_hashes), f);
        
        fclose(f);
        
        printf("Done...");
        fflush(stdout);
    }
        
}

/*
 *  ps2_iso9660_sig
 */
void ps2_iso9660_sig(FILE *f, const char *img_in) {
    
	/* iso9660 offset DVD */
	if(fseek(f, 0x8000, SEEK_SET) == 0) {
		uint8_t buf[8];

		if(fread(buf, 1, 6, f)) {
			if(buf[0] != 0x01 && buf[1] != 0x43 && buf[2] != 0x44 && buf[3] != 0x30 && buf[4] != 0x30 && buf[5] != 0x31)
            {
                /* NOW TRY CD OFFSET */
                fseek(f, 0x9318, SEEK_SET);
                memset(buf, 0, sizeof(buf));
                                
                if(fread(buf, 1, 6, f)) {
                    if(buf[0] != 0x01 && buf[1] != 0x43 && buf[2] != 0x44 && buf[3] != 0x30 && buf[4] != 0x30 && buf[5] != 0x31) {
                        
                        printf("Not a valid ISO9660 Image...:\n");
                        
                        printf(" input\t\t%s [ERROR]\n", img_in);
                        
                        fclose(f);
                        exit(0);
                    }
                }
            }
        }

		fseek(f, 0, SEEK_SET);
	}
}

/*
 * ps2_build_limg
 */
void ps2_build_limg(const char *img_in, int64_t size) {
	int i, b_size = 0;
	uint8_t buf[8], tmp[8], num_sectors[8];
	int64_t tsize=0;

	FILE *f = fopen(img_in, "rb+");

	/* limg offset */
	if(fseek(f, -0x4000, SEEK_END) == 0) {
		if(fread(buf, 1, 4, f)) {
			/* skip */
			if(buf[0] == 0x4c && buf[1] == 0x49 && buf[2] == 0x4d && buf[3] == 0x47) {
				printf("[*] LIMG Header:\n\t\t[OK]\n");
				fclose(f);
				return;
			}
		}
	}
	
	/* seek start */
	fseek(f, 0, SEEK_SET);
	
	// Get MSB Value size, DVD or CD
	if(size > 0x2BC00000) {
        fseek(f, 0x8000 + 0x54, SEEK_SET);
        fread(num_sectors, 1, 4, f);
    } else {
        fseek(f, 0x9318 + 0x54, SEEK_SET);
        fread(num_sectors, 1, 4, f);
    }

	for(i = 0; i < 8; i++)
		buf[i] = tmp[i] = 0x00;
	
	tsize = size;

	/* seek end */
	fseek(f, 0, SEEK_END);
	
	/* Check if image is multiple of 0x4000, if not then pad with zeros*/
	while((tsize%16384) != 0) {
        tsize++;
        fwrite(&buf[0], 1, 1, f);
    }
    
    printf("Multiple of 0x4000 [OK]\n");

	if(size > 0x2BC00000)
		b_size = 0x800; /* dvd */
	else
		b_size = 0x930; /* cd */

	if(b_size == 0x800) {
		buf[3] = 0x01;
		tmp[2] = 0x08;
	} else {
		buf[3] = 0x02;
		tmp[2] = 0x09;
		tmp[3] = 0x30;
	}

	/* print output */
	printf("[*] LIMG Header:\n 4C 49 4D 47 ");

	fwrite("LIMG", 1, 4, f);
	fwrite(buf, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", buf[i]);

	/* write number of sectors*/
	fwrite(num_sectors, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", num_sectors[i]);

	fwrite(tmp, 1, 4, f);

	/* print output */
	for(i = 0; i < 4; i++)
		printf("%02X ", tmp[i]);
		printf("\n");

	/* 0x4000 - 0x10 - Rellena con ceros la seccion final de 16384 bytes */
	for(i = 0; i < 0x3FF0; i++)
		fwrite(&buf[0], 1, 1, f);
		fclose(f);
}

static void build_ps2_header(u8 * buffer, int npd_type, char content_id[], char filename[], s64 iso_size)
{

	int i;
	u32 type = 1;
	u8 test_hash[] = { 0xBF, 0x2E, 0x44, 0x15, 0x52, 0x8F, 0xD7, 0xDD, 0xDB, 0x0A, 0xC2, 0xBF, 0x8C, 0x15, 0x87, 0x51 };

	wbe32(buffer, 0x50533200);			// PS2\0
	wbe16(buffer + 0x4, 0x1);			// ver major
	wbe16(buffer + 0x6, 0x1);			// ver minor
	wbe32(buffer + 0x8, npd_type);			// NPD type XX
	wbe32(buffer + 0xc, type);			// type
		
	wbe64(buffer + 0x88, iso_size); 		//iso size
	wbe32(buffer + 0x84, PS2_DEFAULT_SEGMENT_SIZE); //segment size
	
	strncpy(buffer + 0x10, content_id, 0x30);

	u8 npd_omac_key[0x10];

	for(i=0;i<0x10;i++) npd_omac_key[i] = npd_kek[i] ^ npd_omac_key2[i];

	get_rand(buffer + 0x40, 0x10); //npdhash1
	//memcpy(buffer + 0x40, test_hash, 0x10);

  	int buf_len = 0x30+strlen(filename);
	char *buf = (char*)malloc(buf_len+1);
	memcpy(buf, buffer + 0x10, 0x30);
	strcpy(buf+0x30, filename);
	aesOmacMode1(buffer + 0x50, buf, buf_len, npd_omac_key3, sizeof(npd_omac_key3)*8);  //npdhash2
	free(buf);
	aesOmacMode1(buffer + 0x60, (u8*)(buffer), 0x60, npd_omac_key, sizeof(npd_omac_key)*8);  //npdhash3

}

void ps2_decrypt_image(char mode[], char image_name[], char meta_file[], char data_file[])
{
	FILE * in;
	FILE * data_out;
	FILE * meta_out;

	u8 ps2_data_key[0x10];
	u8 ps2_meta_key[0x10];
	u8 iv[0x10];

	int segment_size;
	s64 data_size;
	int i;
	u8 header[256];
	u8 * data_buffer;
	u8 * meta_buffer;
	u32 read = 0;
	int num_child_segments;
	
	int64_t c, flush_size, decr_size, total_size;
	int percent;
	
	decr_size = c = percent = 0;

	//open files
	in = fopen(image_name, "rb");
	meta_out = fopen(meta_file, "wb");
	data_out = fopen(data_file, "wb");

	//get file info
	read = fread(header, 256, 1, in);
	segment_size = be32(header + 0x84);
	data_size = be64(header + 0x88);
	num_child_segments = segment_size / PS2_META_ENTRY_SIZE;
	
	total_size = data_size;
	flush_size = total_size / 100;

	printf("segment size: %x\ndata_size: %llx\n\n", segment_size, data_size);

	//alloc buffers
	data_buffer = malloc(segment_size*num_child_segments);
	meta_buffer = malloc(segment_size);

	//generate keys
	if(strcmp(mode, "cex") == 0)
	{
		printf("[* CEX] PS2 Classic:\n");
		set_ps2_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}else{
		printf("[* DEX] PS2 Classic:\n");
		set_ps2_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	//decrypt iso
	fseek(in, segment_size, SEEK_SET);
	
	while(data_size > 0)
	{
		//decrypt meta
		read = fread(meta_buffer, 1, segment_size, in);
		aes128cbc(ps2_meta_key, iv, meta_buffer, read, meta_buffer);
		fwrite(meta_buffer, read, 1, meta_out);

		read = fread(data_buffer, 1, segment_size*num_child_segments, in);		
		for(i=0;i<num_child_segments;i++)	
			aes128cbc(ps2_data_key, iv, data_buffer+(i*segment_size), segment_size, data_buffer+(i*segment_size));
		if(data_size >= read)
			fwrite(data_buffer, read, 1, data_out);
		else
			fwrite(data_buffer, data_size, 1, data_out);
			
		c += read;
		if(c >= flush_size) {
			percent += 1;
			decr_size = decr_size + c;
			printf("Decrypted: %d Blocks 0x%08lx\n", percent, decr_size);
			fflush(stdout);
			c = 0;
		}
		
		data_size -= read;
	}

	//cleanup
	free(data_buffer);
	free(meta_buffer);

	fclose(in);
	fclose(data_out);
	fclose(meta_out);
}

void ps2_encrypt_image(char mode[], char image_name[], char data_file[], char real_out_name[], char CID[])
{
	FILE * in;
	FILE * data_out;

	u8 ps2_data_key[0x10];
	u8 ps2_meta_key[0x10];
	u8 iv[0x10];

	u32 segment_size;
	s64 data_size;
	u32 i;
	u8 header[256];
	u8 * data_buffer;
	u8 * meta_buffer;
	u8 * ps2_header;
	
	u32 read = 0;
	u32 num_child_segments = 0x200;
	u32 segment_number = 0;
	
	int64_t c, flush_size, encr_size, total_size;
	int percent;
	
	encr_size = c = percent = 0;

	//open files
	in = fopen(image_name, "rb");
	data_out = fopen(data_file, "wb");
	
	/* iso9660 check */
	ps2_iso9660_sig(in, image_name);

	//Get file info
	segment_size = PS2_DEFAULT_SEGMENT_SIZE;
	fseeko(in, 0, SEEK_END);
	data_size = ftello(in);
	fseeko(in, 0, SEEK_SET);
	
	total_size = data_size;
	
	flush_size = total_size / 100;

	/* limg section */
	ps2_build_limg(image_name, data_size);
	
	// Get new file info -- FIX FAKE SIZE VALUE on PS2 HEADER
	fseeko(in, 0, SEEK_END);
	data_size = ftello(in);
	fseeko(in, 0, SEEK_SET);

	printf("segment size: %x\ndata_size: %llx\nfile name: %s\nContent_id: %s\niso %s\nout file: %s\n", segment_size, data_size, real_out_name, CID, image_name, data_file);

	//prepare buffers
	data_buffer = malloc(segment_size * 0x200);
	meta_buffer = malloc(segment_size);
	ps2_header = malloc(segment_size);
	memset(ps2_header, 0, segment_size);

	//generate keys
	if(strcmp(mode, "cex") == 0)
	{
		printf("[* CEX] PS2 Classic:\n");
		set_ps2_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}else{
		printf("[* DEX] PS2 Classic:\n");
		set_ps2_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	//write incomplete ps2 header
	build_ps2_header(ps2_header, 2, CID, real_out_name, data_size);
	fwrite(ps2_header, segment_size, 1, data_out);

	//write encrypted image
	while(read = fread(data_buffer, 1, segment_size*num_child_segments, in))
	{
		//last segments?
		if(read != (segment_size*num_child_segments)){
			num_child_segments = (read / segment_size);
			if((read % segment_size) > 0)
				num_child_segments++;
		}

		//encrypt data and create meta		
		memset(meta_buffer, 0, segment_size);
		for(i=0;i<num_child_segments;i++)
		{	
			aes128cbc_enc(ps2_data_key, iv, data_buffer+(i*segment_size), segment_size, data_buffer+(i*segment_size));
			sha1(data_buffer+(i*segment_size), segment_size, meta_buffer+(i*PS2_META_ENTRY_SIZE));
			wbe32(meta_buffer+(i*PS2_META_ENTRY_SIZE)+0x14, segment_number);
			segment_number++;
		}

		//encrypt meta
		aes128cbc_enc(ps2_meta_key, iv, meta_buffer, segment_size, meta_buffer);
		
		//write meta and data
		fwrite(meta_buffer, segment_size, 1, data_out);
		fwrite(data_buffer, segment_size, num_child_segments, data_out);
		
		c += read;
		if(c >= flush_size) {
			percent += 1;
			encr_size = encr_size + c;
			printf("Encrypted: %d Blocks 0x%08lx\n", percent, encr_size);
			fflush(stdout);
			c = 0;
		}
	
		memset(data_buffer, 0, segment_size*num_child_segments);
	}

	//finalize ps2_header
	// - wtf is between signature and first segment?

	//cleanup
	free(data_buffer);
	free(meta_buffer);
	free(ps2_header);

	fclose(in);
	fclose(data_out);
}

void ps2_crypt_vmc(char mode[], char vmc_path[], char vmc_out[], int crypt_mode)
{
	FILE * in;
	FILE * data_out;
	FILE * meta_out;

	u8 ps2_vmc_key[0x10];
	u8 iv[0x10];

	int segment_size, data_size;
	int i;
	u8 header[256];
	u8 * data_buffer;
	u8 * meta_buffer;
	u32 read = 0;

	segment_size = PS2_DEFAULT_SEGMENT_SIZE;
	
	// Validate new hashes
	if (crypt_mode == PS2_VMC_ENCRYPT)
	   vmc_hash(vmc_path);

	//open files
	in = fopen(vmc_path, "rb");
	data_out = fopen(vmc_out, "wb");

	//alloc buffers
	data_buffer = malloc(segment_size);

	//generate keys
	if(strcmp(mode, "cex") == 0)
	{
        printf("cex\n");
		memcpy(ps2_vmc_key, ps2_key_cex_vmc, 0x10);
	}else{
        printf("dex\n");
		memcpy(ps2_vmc_key, ps2_key_dex_vmc, 0x10);
	}
	
	memset(iv+8, 0, 8);

	while(read = fread(data_buffer, 1, segment_size, in))
	{
		//decrypt or encrypt vmc
		if(crypt_mode == PS2_VMC_DECRYPT)
			aes128cbc(ps2_vmc_key, ps2_iv, data_buffer, read, data_buffer);
		else
		{
            aes128cbc_enc(ps2_vmc_key, ps2_iv, data_buffer, read, data_buffer);
        }
		fwrite(data_buffer, read, 1, data_out);

	}

	//cleanup
	free(data_buffer);

	fclose(in);
	fclose(data_out);
	
}

int main(int argc, char *argv[])
{
	
	if(argc == 1)
	{
		printf("usage:\n\tiso:\n\t\t%s d [cex/dex] [klicensee] [encrypted image] [out data] [out meta]\n", argv[0]);
		printf("\t\t%s e [cex/dex] [klicensee] [iso] [out data] [real out name] [CID]\n", argv[0]);
		printf("\tvmc:\n\t\t%s vd [cex/dex] [vme file] [out vmc]\n", argv[0]);
		printf("\t\t%s ve [cex/dex] [vmc file] [out vme]\n", argv[0]);
		exit(0);
	}
	
    klicensee = mmap_file(argv[3]);

	if(strcmp(argv[1], "d") == 0)
		if(argc == 7)
			ps2_decrypt_image(argv[2], argv[4], argv[6], argv[5]);
		else
			printf("Error: invalid number of arguments for decryption\n");
	else if(strcmp(argv[1], "e") == 0)
		if(argc == 8)
			ps2_encrypt_image(argv[2], argv[4], argv[5], argv[6], argv[7]);
		else
			printf("Error: invalid number of arguments for encryption\n");
	else if(strcmp(argv[1], "vd") == 0 || strcmp(argv[1], "ve") == 0)
	{
		if(argc != 5)
		{
            printf("Error: invalid number of arguments for vme processing\n");
			exit(0);
		}
			
		if(strcmp(argv[1], "vd") == 0)
			ps2_crypt_vmc(argv[2], argv[3], argv[4], PS2_VMC_DECRYPT);
		else 
			ps2_crypt_vmc(argv[2], argv[3], argv[4], PS2_VMC_ENCRYPT);
			
	}

}
