
unsigned char ps2_key_dex_vmc[0x10] = {
	0x30, 0x47, 0x9D, 0x4B, 0x80, 0xE8, 0x9E, 0x2B,
	0x59, 0xE5, 0xC9, 0x14, 0x5E, 0x10, 0x64, 0xA9
};

unsigned char ps2_iv[0x10] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

unsigned char fallback_header_hash[0x10] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01
};

unsigned char npd_omac_key2[0x10] = {
	0x6B, 0xA5, 0x29, 0x76, 0xEF, 0xDA, 0x16, 0xEF,
	0x3C, 0x33, 0x9F, 0xB2, 0x97, 0x1E, 0x25, 0x6B
};

unsigned char npd_omac_key3[0x10] = {
	0x9B, 0x51, 0x5F, 0xEA, 0xCF, 0x75, 0x06, 0x49,
	0x81, 0xAA, 0x60, 0x4D, 0x91, 0xA5, 0x4E, 0x97
};

unsigned char npd_kek[0x10] = {
	0x72, 0xF9, 0x90, 0x78, 0x8F, 0x9C, 0xFF, 0x74,
	0x57, 0x25, 0xF0, 0x8E, 0x4C, 0x12, 0x83, 0x87
};

static int cex_mode = 1, img_padd = 0;
static unsigned char *klicensee;

/*
 *  ps2_set_iv
 */
void ps2_set_iv(unsigned char *iv) {
	memcpy(iv, ps2_iv, 0x10);
}

/*
 * ps2_vmc_hash
 */
void ps2_vmc_hash(const char *vmc) {
	unsigned char seg_hashes[0x4000], seg_data[0x4000], sha1_hash[0x14], buf[4];
	long vmc_size, m_size = 0;
	int seg_count, i;

	FILE *f = fopen(vmc, "rb+");

	memset(seg_hashes, 0, 0x4000);

	if(fread(buf, 1, 4, f)) {
		if(buf[0] != 0x53 && buf[1] != 0x6F && buf[2] != 0x6E && buf[3] != 0x79) {
			printf(" ps2_vmc\t[NO ]\n", vmc);

			exit(1);
		}
	}

	printf(" ps2_vmc\t[YES]\n");

        fseek(f, 0, SEEK_END);
        vmc_size = ftell(f);

        seg_count = (vmc_size - 0x4000) / 0x4000;

	printf("\n rehash\n");

        for(i = 0; i < seg_count; i++) {
		fseek(f, (i * 0x4000), SEEK_SET);
		m_size += fread(seg_data, 1, 0x4000, f);
		sha1(seg_data, 0x4000, sha1_hash);
		memcpy(seg_hashes + i * 0x14, sha1_hash, 0x14);

		printf("\t\tblock 0x%08lx\n", m_size);
        }	printf("\n");

        fseek(f, (seg_count * 0x4000), SEEK_SET);

        fwrite(seg_hashes, 1, 0x4000, f);

        fclose(f);
}

/*
 * ps2_crypt_vmc
 */
void ps2_crypt_vmc(const char *vmc_in, const char *vmc_out, const int crypt_mode) {
	FILE *in, *out;
	unsigned char ps2_vmc_key[0x10], iv[0x10], *buf;
	int read;

	printf(" input\t\t%s\n", vmc_in);

	/* validate hashes */
	if(crypt_mode == PS2_VMC_ENCRYPT)
		ps2_vmc_hash(vmc_in);

	in = fopen(vmc_in, "rb");
	out = fopen(vmc_out, "wb");

	buf = (unsigned char *)malloc(PS2_DEFAULT_SEGMENT_SIZE);

	/* generate keys */
	if(cex_mode == 1)
		memcpy(ps2_vmc_key, ps2_key_cex_vmc, 0x10);
	else
		memcpy(ps2_vmc_key, ps2_key_dex_vmc, 0x10);

	memset(iv + 8, 0, 8);

	while(read = fread(buf, 1, PS2_DEFAULT_SEGMENT_SIZE, in)) {
		/* decrypt or encrypt vmc */
		if(crypt_mode == PS2_VMC_DECRYPT)
			aes128cbc(ps2_vmc_key, ps2_iv, buf, read, buf);
		else
			aes128cbc_enc(ps2_vmc_key, ps2_iv, buf, read, buf);

		fwrite(buf, read, 1, out);
	}

	printf(" output\t\t%s\n", vmc_out);

	/* free */
	free(buf);

	fclose(in);
	fclose(out);
}

/*
 *  ps2_build_header
 */
void ps2_build_header(unsigned char *buf, int npd_type, const char *content_id, const char *img_out, long img_size) {
	unsigned char npd_omac_key[0x10], *tmp;
	int len, i;

	wbe32(buf, 0x50533200);		/* PS2\0 */
	wbe16(buf + 0x04, 0x01);	/* ver major */
	wbe16(buf + 0x06, 0x01);	/* ver minor */
	wbe32(buf + 0x08, npd_type);	/* NPD type XX */
	wbe32(buf + 0x0c, 0x01);	/* type */
	wbe64(buf + 0x88, img_size);			/* img size */
	wbe32(buf + 0x84, PS2_DEFAULT_SEGMENT_SIZE);	/* segment size */

	strncpy(buf + 0x10, content_id, 0x30);

	for(i = 0; i < 0x10; i++)
		npd_omac_key[i] = npd_kek[i] ^ npd_omac_key2[i];

	/* npdhash1 */
	get_rand(buf + 0x40, 0x10);

  	len = strlen(img_out) + 0x30;
	tmp = (unsigned char *)malloc(len + 1);

	memcpy(tmp, buf + 0x10, 0x30);
	strcpy(tmp + 0x30, img_out);

	/* npdhash2 */
	aesOmacMode1(buf + 0x50, tmp, len, npd_omac_key3, 128);
	/* npdhash3 */
	aesOmacMode1(buf + 0x60, buf, 0x60, npd_omac_key, 128);

	/* free */
	free(tmp);
}

/*
 * ps2_build_limg
 */
void ps2_build_limg(const char *img, long size) {
	unsigned char buf[16], msb[4];
	long t_size = size;
	int i, b_size = 0x800;

	FILE *f = fopen(img, "rb+");

	/* limg offset */
	fseek(f, -0x4000, SEEK_END);

	if(fread(buf, 1, 4, f)) {
		if(buf[0] == 0x4C && buf[1] == 0x49 && buf[2] == 0x4D && buf[3] == 0x47) {
			fclose(f);

			printf(" limg\t\t[OK]\n\n");
			return;
		}
	}

	memset(buf, 0, 16);

	/* dvd/cd - msb size */
	if(size > 0x2BF20000) {
        	fseek(f, 0x8000 + 0x54, SEEK_SET);
			if(fread(msb, 1, 4, f))
				b_size = 0x800;
	} else {
		fseek(f, 0x9318 + 0x54, SEEK_SET);
			if(fread(msb, 1, 4, f))
				b_size = 0x930;
	}

	/* seek end */
	fseek(f, 0, SEEK_END);

	/* pad with zeros if image is not multiple of 0x4000 */
	while((++t_size % 0x4000))
		fwrite(&buf[0], 1, 1, f);

	img_padd = t_size - size;

	wbe32(buf + 0x00, 0x4C494D47);	/* limg magic */
	memcpy(buf + 0x08, msb, 4);	/* msb size */

	if(b_size == 0x800) {
		wbe32(buf + 0x04, 0x01);
		wbe32(buf + 0x0C, 0x800);
	} else {
		wbe32(buf + 0x04, 0x02);
		wbe32(buf + 0x0C, 0x930);
	}

	fwrite(buf, 1, 16, f);

	/* output */
	printf(" limg\t\t0x");

	for(i = 0; i < 16; i++)
		printf("%02x", buf[i]);
		printf("\n\n");

	memset(buf, 0, 16);

	/* 0x4000 - 0x10 - Rellena con ceros la seccion final de 16384 bytes */
	for(i = 0; i < 0x3FF0; i++)
		fwrite(&buf[0], 1, 1, f);

	fclose(f);
}

/*
 *  ps2_iso9660
 */
void ps2_iso9660(FILE *f, const char *img) {
	unsigned char buf[8];

	/* dvd offset */
	fseek(f, 0x8000, SEEK_SET);

	if(fread(buf, 1, 6, f)) {
		if(buf[0] != 0x01 && buf[1] != 0x43 && buf[2] != 0x44 && buf[3] != 0x30 && buf[4] != 0x30 && buf[5] != 0x31) {
			/* cd offset */
                	fseek(f, 0x9318, SEEK_SET);

			if(fread(buf, 1, 6, f)) {
				if(buf[0] != 0x01 && buf[1] != 0x43 && buf[2] != 0x44 && buf[3] != 0x30 && buf[4] != 0x30 && buf[5] != 0x31) {
					printf(" input\t\t%s\n iso9660\t[NO ]\n", img);

					exit(1);
				}
			}
		}
	}
}

/*
 * ps2_decrypt_image
 */
void ps2_decrypt_image(const char *img_in, const char *img_out, const char *meta_out) {
	FILE *in, *me, *out;
	unsigned char ps2_data_key[0x10], ps2_meta_key[0x10], header[0x100], iv[0x10], *data_buf, *meta_buf;
	int child_seg_num, seg_size, read, i;
	long img_size, d_size, f_size, c;

	d_size = c = 0;

	in = fopen(img_in, "rb");
	me = fopen(meta_out, "wb");
	out = fopen(img_out, "wb");

	read = fread(header, 256, 1, in);
	seg_size = be32(header + 0x84);
	img_size = be64(header + 0x88);
	child_seg_num = seg_size / PS2_META_ENTRY_SIZE;

	f_size = img_size / 100;

	printf( " input\t\t%s\n"
		" seg_size\t0x%08x\n"
		" img_size\t0x%08lx\n"
		" klicensee\t0x", img_in, seg_size, img_size);

	for(i = 0; i < 0x10; i++)
		printf("%02x", klicensee[i]);

	data_buf = (unsigned char *)malloc(seg_size * child_seg_num);
	meta_buf = (unsigned char *)malloc(seg_size);

	/* generate keys */
	if(cex_mode == 1) {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	} else {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	printf("\n\n decrypt\n");

	/* decrypt iso */
	fseek(in, seg_size, SEEK_SET);

	while(img_size > 0) {
		/* decrypt meta */
		read = fread(meta_buf, 1, seg_size, in);
		aes128cbc(ps2_meta_key, iv, meta_buf, read, meta_buf);
		fwrite(meta_buf, read, 1, me);

		read = fread(data_buf, 1, seg_size * child_seg_num, in);
		for(i = 0; i < child_seg_num; i++)
			aes128cbc(ps2_data_key, iv, data_buf + (i * seg_size), seg_size, data_buf + (i * seg_size));

		if(img_size >= read)
			fwrite(data_buf, read, 1, out);
		else
			fwrite(data_buf, img_size, 1, out);

		c += read;
		if(c >= f_size) {
			d_size += c;
			printf("\t\tblock 0x%08lx\n", d_size);
			c = 0;
		}

		img_size -= read;
	}

	printf("\n output\t\t%s\n", img_out);

	/* free */
	free(data_buf);
	free(meta_buf);

	fclose(in);
	fclose(me);
	fclose(out);
}

/*
 * ps2_encrypt_image
 */
void ps2_encrypt_image(const char *img_in, const char *img_out, const char *content_id) {
	FILE *in, *out;
	unsigned char ps2_data_key[0x10], ps2_meta_key[0x10], iv[0x10], *ps2_header, *data_buf, *meta_buf;
	unsigned int child_seg_num, seg_num, read, i;
	long img_size, e_size, f_size, c;

	child_seg_num = 0x200;
	seg_num = e_size = c = 0;

	in = fopen(img_in, "rb");
	out = fopen(img_out, "wb");

	/* iso9660 check */
	ps2_iso9660(in, img_in);

	/* img size */
	fseek(in, 0, SEEK_END);
	img_size = ftell(in);

	/* limg section */
	ps2_build_limg(img_in, img_size);

	/* new img size -- FIX FAKE SIZE VALUE on PS2 HEADER */
	fseek(in, 0, SEEK_END);
	img_size = ftell(in);
	fseek(in, 0, SEEK_SET);

	f_size = img_size / 100;

	printf( " input\t\t%s\n"
		" iso9660\t[YES]\n"
		" seg_size\t0x%08x\n"
		" img_padd\t0x%08x\n"
		" img_size\t0x%08lx\n"
		" klicensee\t0x", img_in, PS2_DEFAULT_SEGMENT_SIZE, img_padd, img_size);

	for(i = 0; i < 0x10; i++)
		printf("%02x", klicensee[i]);
		printf("\n content_id\t%s\n", content_id);

	data_buf = (unsigned char *)malloc(PS2_DEFAULT_SEGMENT_SIZE * 0x200);
	meta_buf = (unsigned char *)malloc(PS2_DEFAULT_SEGMENT_SIZE);
	ps2_header = (unsigned char *)malloc(PS2_DEFAULT_SEGMENT_SIZE);

	memset(ps2_header, 0, PS2_DEFAULT_SEGMENT_SIZE);

	/* generate keys */
	if(cex_mode == 1) {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_cex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_cex_meta, iv, klicensee, 0x10, ps2_meta_key);
	} else {
		ps2_set_iv(iv);
		aes128cbc_enc(ps2_key_dex_data, iv, klicensee, 0x10, ps2_data_key);
		aes128cbc_enc(ps2_key_dex_meta, iv, klicensee, 0x10, ps2_meta_key);
	}

	/* write incomplete ps2 header */
	ps2_build_header(ps2_header, 2, content_id, img_out, img_size);
	fwrite(ps2_header, PS2_DEFAULT_SEGMENT_SIZE, 1, out);

	printf("\n encrypt\n");

	/* write encrypted image */
	while(read = fread(data_buf, 1, PS2_DEFAULT_SEGMENT_SIZE * child_seg_num, in)) {
		/* last segments? */
		if(read != (PS2_DEFAULT_SEGMENT_SIZE * child_seg_num)) {
			child_seg_num = (read / PS2_DEFAULT_SEGMENT_SIZE);
			if((read % PS2_DEFAULT_SEGMENT_SIZE) > 0)
				child_seg_num++;
		}

		memset(meta_buf, 0, PS2_DEFAULT_SEGMENT_SIZE);
		/* encrypt data and create meta */
		for(i = 0; i < child_seg_num; seg_num++, i++) {
			aes128cbc_enc(ps2_data_key, iv, data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE), PS2_DEFAULT_SEGMENT_SIZE, data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE));
			sha1(data_buf + (i * PS2_DEFAULT_SEGMENT_SIZE), PS2_DEFAULT_SEGMENT_SIZE, meta_buf + (i * PS2_META_ENTRY_SIZE));
			wbe32(meta_buf + (i * PS2_META_ENTRY_SIZE) + 0x14, seg_num);
		}

		/* encrypt meta */
		aes128cbc_enc(ps2_meta_key, iv, meta_buf, PS2_DEFAULT_SEGMENT_SIZE, meta_buf);

		/* write meta and data */
		fwrite(meta_buf, PS2_DEFAULT_SEGMENT_SIZE, 1, out);
		fwrite(data_buf, PS2_DEFAULT_SEGMENT_SIZE, child_seg_num, out);

		c += read;
		if(c >= f_size) {
			e_size += c;
			printf("\t\tblock 0x%08lx\n", e_size);
			c = 0;
		}

		memset(data_buf, 0, PS2_DEFAULT_SEGMENT_SIZE * child_seg_num);
	}

	printf("\n output\t\t%s\n", img_out);

	//finalize ps2_header
	// - wtf is between signature and first segment?

	/* free */
	free(data_buf);
	free(meta_buf);
	free(ps2_header);

	fclose(in);
	fclose(out);
}

/*
 * usage
 */
void usage() {
	printf( "vm:\n"
		"\tps2classic -ve cex|dex vmc vme\n"
		"\tps2classic -vd cex|dex vme vmc\n"
		"img:\n"
		"\tps2classic -e cex|dex klicensee image_in image_out content_id\n"
		"\tps2classic -d cex|dex klicensee image_in image_out meta\n");

	exit(1);
}

/*
 * main
 */
int main(int argc, char **argv) {
	if(argc < 5 || argc > 7)
		usage();

	if(strncmp(argv[2], "dex", 3) == 0)
		cex_mode = 0;

	if(cex_mode == 1)
		printf("[* CEX] PS2 Classic:\n");
	else
		printf("[* DEX] PS2 Classic:\n");

	/* encrypt img */
	if(strncmp(argv[1], "-e", 2) == 0) {
		klicensee = mmap_file(argv[3]);

		if(argc == 7)
			ps2_encrypt_image(argv[4], argv[5], argv[6]);
		else
			usage();
	}

	/* decrypt img */
	else if(strncmp(argv[1], "-d", 2) == 0) {
		klicensee = mmap_file(argv[3]);

		if(argc == 7)
			ps2_decrypt_image(argv[4], argv[5], argv[6]);
		else
			usage();
	}

	/* encrypt/decrypt vm */
	else if(strncmp(argv[1], "-vd", 3) == 0 || strncmp(argv[1], "-ve", 3) == 0) {
		if(argc != 5)
			usage();

		if(strncmp(argv[1], "-vd", 3) == 0)
			ps2_crypt_vmc(argv[3], argv[4], PS2_VMC_DECRYPT);
		else 
			ps2_crypt_vmc(argv[3], argv[4], PS2_VMC_ENCRYPT);
	} else
		usage();

	return 0;
}