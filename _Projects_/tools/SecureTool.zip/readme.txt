Presenting: SecureTool, an alternative to scetool, with lots of new features.

SecureTool v2.16 - xorloser 2008-2022 (Thu Feb 3 16:37:52 2022)
Usage: SecureTool <options> <secure filename>
Options:
-ms <base filename> = make self file from base file
-mr <base filename> = make rvk file from base file
-mp <base filename> = make pkg file from base file
-md <base filename> = make spp file from base file
-b <base filename> = extract base file from secure file
-g <info filename> = get info about a secure file into an info file
-s <info filename> = set info in a secure file from an info file
-o <out filename> = output altered secure file to a new file
-h <patch filename> = patch secure file with patch file
-a <auth id> = set 64bit authority id in self file
-v <version> = set 64bit version in secure file
-c <flag> = alter file compression (0/1)
	0 = uncompressed
	1 = compressed
-e <flag> = alter file encryption (0/1)
	0 = unencrypted
	1 = encrypted
-t <type> = set self type (0/1/2/a/i/l/n/p)
	0 = lv0
	1 = lv1
	2 = lv2
	a = application
	i = isolated spu module
	l = loader
	n = npdrm application
	p = ps2 emulator
-p <flags> = print info about secure file (a/c/e/f/i/o/s/x/y)
	a = print all
	c = print secure file info
	e = print exports
	f = print elf/prx info
	i = print imports
	o = print offsets
	s = print syscalls
	x = print extended info about imports/exports
	y = print symbols
-ra <address> = read data at address (default is 0)
-rs <size> = size of data to read at address (default is 1)
-rb <size> = data blocksize. 1=8bit, 2=16bit.. (default is 1)
-k <name> = name of keyset to use for encryption and signing
-l = list all keysets
	ALL keys are embedded in the executable
	(except for the .2 keys of course).
-j = set self file to run as a jig self
-d = set self file to run as a disc self
-q = quiet mode, dont print title

Notes:
* If a secure filename is given but no options, this tool will print basic
info on the secure file.

My favorite option is the ability to list all the exports with the command
SecureTool.exe -pex <name of self or sprx>
